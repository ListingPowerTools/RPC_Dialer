import React from 'react'
import './styles.scss'

class Panel1 extends React.Component {
  render() {
    return (
      <div className='panel-one'>
        <p>Panel 1</p>
      </div>
    )
  }
}

export default Panel1