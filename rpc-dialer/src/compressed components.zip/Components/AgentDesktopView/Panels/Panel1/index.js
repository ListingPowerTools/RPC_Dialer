import Panel1 from './Panel1'

export default Panel1