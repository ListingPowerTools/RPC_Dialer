import Panel1 from './Panel1'
import Panel2 from './Panel2'

export {
  Panel1,
  Panel2
}