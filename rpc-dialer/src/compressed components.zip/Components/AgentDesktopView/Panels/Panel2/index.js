import Panel2 from './Panel2'

export default Panel2