import React from 'react'
import './styles.scss'

class Panel2 extends React.Component {
  render() {
    return (
      <div className='panel-two'>
        <p>Panel 2</p>
      </div>
    )
  }
}

export default Panel2